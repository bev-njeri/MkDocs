# mkdocs-material-youtube-tutorial

Supporting code for my YouTube tutorial video:

[![Image.png](https://raw.githubusercontent.com/james-willett/mkdocs-material-youtube-tutorial/main/MkDocsMaterial_GH_Thumbnail.png)](https://www.youtube.com/watch?v=Q-YA_dA8C20)
